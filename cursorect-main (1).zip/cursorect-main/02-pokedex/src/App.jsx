
import Navbar from './components/Navbar'
import Pokemones from './components/Pokemones'

function App() {

  return (
    <>
      <Navbar />
      <Pokemones />
    </>
  )
}

export default App
