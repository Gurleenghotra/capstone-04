
const Texto = (props) => {
    return (
        <p>Hola mi nombre es:{props.name}
        {props.apellido} y mi edad es: {props.edad}</p>
    )
}

export default Texto