
const Message = ({ text }) => <h3 className="error-message">{ text }</h3>

export default Message