const Loader = () => <div className="loader"></div>

export default Loader